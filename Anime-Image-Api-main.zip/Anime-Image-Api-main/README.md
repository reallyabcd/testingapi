# Anime-Image-Api
Django custom image rendering 

# Preview

![home](https://user-images.githubusercontent.com/79472476/230879929-9e58b21b-2670-4881-9571-733c4003f4e3.jpeg)

![id](https://user-images.githubusercontent.com/79472476/230879934-9b1bfec9-7cbb-4a7f-8b21-195e038bb433.jpeg)

![cate](https://user-images.githubusercontent.com/79472476/230879939-9e211f53-c068-4a9d-974a-c05d1db279be.jpeg)


# Remaining Features

Integrating the DRF api to react-native
